import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

import { Card, CardContent } from "@/components/ui/card";
import { useProfileCompletion } from "@/features/onboarding/hooks/useProfileCompletion";
import ProfileForm from "@/features/onboarding/components/ProfileForm";

export default function OnboardingPage() {
  const { loading, profile, complete, refresh } = useProfileCompletion();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && complete) {
      navigate("/dashboard", { replace: true });
    }
  }, [loading, complete, navigate]);

  const handleCompleted = async () => {
    // 1) Refresca el perfil local (para que posteriores lecturas lo vean completo)
    await refresh();
    // 2) Marca bypass de una sola vez
    sessionStorage.setItem("onboardingJustCompleted", "1");
    // 3) Navega al dashboard
    navigate("/dashboard", { replace: true });
  };

  if (loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Card className="p-6">
          <CardContent className="p-0">Cargando…</CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto max-w-3xl py-6">
      <h1 className="mb-2 text-2xl font-semibold">¡Bienvenido! 🏋️</h1>
      <p className="mb-6 text-muted-foreground">
        Antes de empezar, necesitamos algunos datos para personalizar tu experiencia.
      </p>
      <ProfileForm
        defaults={{
          username: profile?.username ?? undefined,
          nombre: profile?.nombre ?? undefined,
          edad: (profile?.edad ?? undefined) as any,
          peso: (profile?.peso ?? undefined) as any,
          altura: (profile?.altura ?? undefined) as any,
          nivel_experiencia: profile?.nivel_experiencia ?? undefined,
          objetivo: profile?.objetivo ?? undefined,
        }}
        onCompleted={handleCompleted}
      />
    </div>
  );
}
