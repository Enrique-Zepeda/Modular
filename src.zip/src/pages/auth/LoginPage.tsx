import { z } from "zod";
import { useNavigate, Link } from "react-router-dom";
import { loginUser } from "@/features/auth/thunks/authThunks";
import { useAppDispatch, useAppSelector } from "@/hooks";
import { useAuthForm } from "@/hooks/useAuthForm";

import { ThemeToggleButton } from "@/features/theme/components/ThemeToggleButton";
import { Button } from "@/components/ui/button";
import { FormBuilder } from "@/components/form/FormBuilder";

const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "La contraseña debe tener al menos 6 caracteres"),
});

export default function LoginPage() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { loading } = useAppSelector((state) => state.auth);

  const form = useAuthForm(loginSchema);

  const onSubmit = async (data: any) => {
    await dispatch(loginUser(data.email, data.password));
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background text-foreground py-12 px-4">
      <div className="absolute top-4 right-4">
        <ThemeToggleButton />
      </div>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 max-w-md w-full">
        <h2 className="text-center text-3xl font-bold">Iniciar sesión</h2>

        <FormBuilder
          fields={[
            { name: "email", label: "Correo", type: "email", placeholder: "correo@ejemplo.com" },
            { name: "password", label: "Contraseña", type: "password", placeholder: "********" },
          ]}
          form={form}
        />

        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? "Iniciando sesión..." : "Iniciar sesión"}
        </Button>

        <p className="text-center text-sm">
          ¿No tienes cuenta?{" "}
          <Link to="/register" className="text-primary hover:underline">
            Regístrate aquí
          </Link>
        </p>
      </form>
    </div>
  );
}
