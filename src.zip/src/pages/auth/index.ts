export { default as LoginPage } from "./LoginPage";
export { default as RegisterPage } from "./RegisterPage";
