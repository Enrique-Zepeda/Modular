import { FormField } from "./FormField";

interface FieldProps {
  name: string;
  label: string;
  type?: string;
  placeholder?: string;
}

interface Props {
  fields: FieldProps[];
  form: {
    register: any;
    formState: { errors: any };
  };
}

export const FormBuilder = ({ fields, form }: Props) => {
  return (
    <>
      {fields.map((field) => (
        <FormField
          key={field.name}
          label={field.label}
          placeholder={field.placeholder}
          type={field.type}
          registration={form.register(field.name)}
          error={form.formState.errors[field.name]}
        />
      ))}
    </>
  );
};
