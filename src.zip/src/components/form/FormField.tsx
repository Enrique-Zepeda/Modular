import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { FieldError, UseFormRegisterReturn } from "react-hook-form";

interface FormFieldProps {
  label: string;
  placeholder: string;
  type?: string;
  registration: UseFormRegisterReturn;
  error?: FieldError;
}

export function FormField({ label, placeholder, type = "text", registration, error }: FormFieldProps) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Input placeholder={placeholder} type={type} {...registration} />
      {error && <p className="text-sm text-destructive">{error.message}</p>}
    </div>
  );
}
