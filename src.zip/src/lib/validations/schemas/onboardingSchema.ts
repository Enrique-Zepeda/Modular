import { z } from "zod";

// Opciones (ajústalas si tu CHECK en BD usa otros literales)
export const NIVELES = ["principiante", "intermedio", "avanzado"] as const;
export const OBJETIVOS = ["fuerza", "hipertrofia", "salud"] as const;

export const onboardingSchema = z.object({
  username: z
    .string({ required_error: "El nombre de usuario es obligatorio" })
    .min(3, "Mínimo 3 caracteres")
    .max(20, "Máximo 20 caracteres")
    .regex(/^[A-Za-z0-9_]+$/, "Solo letras, números y guión bajo"),
  nombre: z
    .string({ required_error: "Tu nombre es obligatorio" })
    .min(2, "Mínimo 2 caracteres")
    .max(100, "Máximo 100 caracteres"),
  edad: z
    .number({ invalid_type_error: "Edad inválida" })
    .int("Debe ser entero")
    .min(13, "Mínimo 13 años")
    .max(100, "Máximo 100 años"),
  peso: z.number({ invalid_type_error: "Peso inválido" }).positive("Debe ser > 0"),
  // EXACTAMENTE 3 dígitos: 100..999 (sin decimales)
  altura: z
    .number({ invalid_type_error: "Altura inválida" })
    .int("Debe ser entero")
    .min(100, "Debe tener 3 dígitos (mín. 100)")
    .max(999, "Debe tener 3 dígitos (máx. 999)"),
  // Selects controlados
  nivel_experiencia: z.enum(NIVELES, { required_error: "Selecciona tu nivel" }),
  objetivo: z.enum(OBJETIVOS, { required_error: "Selecciona tu objetivo" }),
});

export type OnboardingFormValues = z.infer<typeof onboardingSchema>;
export type NivelExperiencia = (typeof NIVELES)[number];
export type Objetivo = (typeof OBJETIVOS)[number];
