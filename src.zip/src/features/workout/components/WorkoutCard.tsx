import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Trash2, Check } from "lucide-react";
import { toast } from "react-hot-toast";
import type { WorkoutListItem } from "@/features/workout/api/workoutsApi";

type Props = {
  workout: WorkoutListItem;
  onDelete?: (id_sesion: number) => Promise<void> | void;
};

function fmt(dt: string | null | undefined) {
  if (!dt) return "—";
  const d = new Date(dt);
  return d.toLocaleString();
}

export function WorkoutCard({ workout, onDelete }: Props) {
  const totalSets = workout.sets?.length ?? 0;
  const doneSets = workout.sets?.filter((s) => s.done).length ?? 0;

  async function handleDelete() {
    if (!onDelete) return;
    const ok = confirm("¿Eliminar este entrenamiento? Esta acción no se puede deshacer.");
    if (!ok) return;
    try {
      await onDelete(workout.id_sesion);
      toast.success("Entrenamiento eliminado");
    } catch (e: any) {
      console.error(e);
      toast.error("No se pudo eliminar");
    }
  }

  return (
    <Card>
      <CardHeader className="flex-row items-center justify-between gap-4">
        <div>
          <CardTitle className="text-base">{workout.Rutinas?.nombre ?? "Entrenamiento"}</CardTitle>
          <div className="text-xs text-muted-foreground">
            {fmt(workout.ended_at)} • {Math.max(0, workout.duracion_seg ?? 0)} s
          </div>
        </div>
        <Button variant="ghost" size="icon" onClick={handleDelete} title="Eliminar entrenamiento">
          <Trash2 className="h-4 w-4" />
        </Button>
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-4 text-sm">
          <span>
            Volumen: <strong>{(workout.total_volumen ?? 0).toLocaleString()} kg</strong>
          </span>
          <span>
            Sets:{" "}
            <strong>
              {doneSets}/{totalSets}
            </strong>
          </span>
          {workout.sensacion_global && <span>🤔 {workout.sensacion_global}</span>}
        </div>

        <Separator />

        {/* Resumen por serie hecha */}
        <div className="space-y-1">
          {(workout.sets ?? [])
            .filter((s) => s.done)
            .map((s, i) => (
              <div key={`${s.id_ejercicio}-${s.idx}-${i}`} className="flex items-center justify-between text-sm">
                <div className="text-muted-foreground">
                  Ejercicio #{s.id_ejercicio} · Set {s.idx}
                </div>
                <div className="flex items-center gap-2">
                  <span className="tabular-nums">
                    {s.kg} kg × {s.reps} reps
                  </span>
                  <Check className="h-4 w-4 text-green-600" />
                </div>
              </div>
            ))}
          {(!workout.sets || workout.sets.filter((s) => s.done).length === 0) && (
            <div className="text-sm text-muted-foreground">No hay sets completados.</div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
