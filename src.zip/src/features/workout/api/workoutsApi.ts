import { createApi, fakeBaseQuery } from "@reduxjs/toolkit/query/react";
import { supabase } from "@/lib/supabase/client";

/** ===== Tipos ===== **/
export type WorkoutSetInput = {
  id_ejercicio: number;
  idx: number;
  kg: number;
  reps: number;
  rpe?: string | null;
  done?: boolean;
  done_at?: string | null;
};

export type CreateWorkoutInput = {
  id_rutina: number;
  started_at: string;
  ended_at: string;
  duracion_seg: number;
  total_volumen: number;
  sensacion_global?: string | null;
  notas?: string | null;
  sets: WorkoutSetInput[];
};

export type CreateWorkoutResult = { id_sesion: number };

export type WorkoutListItem = {
  id_sesion: number;
  started_at: string;
  ended_at: string | null;
  duracion_seg: number | null;
  total_volumen: number | null;
  sensacion_global: string | null;
  notas: string | null;
  Rutinas?: { id_rutina: number; nombre: string | null } | null;
  sets?: Array<{
    id_ejercicio: number;
    idx: number;
    kg: number;
    reps: number;
    rpe: string | null;
    done: boolean;
  }>;
};

export const workoutsApi = createApi({
  reducerPath: "workoutsApi",
  baseQuery: fakeBaseQuery(),
  tagTypes: ["Workouts"],
  endpoints: (builder) => ({
    /** Crear sesión (RPC) */
    createWorkoutSession: builder.mutation<CreateWorkoutResult, CreateWorkoutInput>({
      async queryFn(payload) {
        const { data, error } = await supabase.rpc("create_workout_session", {
          p_id_rutina: payload.id_rutina,
          p_started_at: payload.started_at,
          p_ended_at: payload.ended_at,
          p_duracion_seg: payload.duracion_seg,
          p_total_volumen: payload.total_volumen,
          p_sensacion_global: payload.sensacion_global ?? null,
          p_notas: payload.notas ?? null,
          p_sets: payload.sets as any,
        });
        if (error) return { error };
        const id_sesion = Array.isArray(data) ? data[0]?.id_sesion : (data as any)?.id_sesion;
        return { data: { id_sesion } };
      },
      invalidatesTags: [{ type: "Workouts", id: "LIST" }],
    }),

    /** Listar sesiones del usuario (finalizadas), con sets “done” */
    listUserWorkouts: builder.query<WorkoutListItem[], void>({
      async queryFn() {
        const { data: ses, error } = await supabase
          .from("Entrenamientos")
          .select(
            `
            id_sesion, started_at, ended_at, duracion_seg, total_volumen, sensacion_global, notas,
            Rutinas: id_rutina ( id_rutina, nombre ),
            sets: EntrenamientoSets ( id_ejercicio, idx, kg, reps, rpe, done )
          `
          )
          .not("ended_at", "is", null)
          .order("ended_at", { ascending: false });
        if (error) return { error };
        return { data: (ses ?? []) as WorkoutListItem[] };
      },
      providesTags: [{ type: "Workouts", id: "LIST" }],
    }),

    /** Borrar sesión (RPC; fallback a 2 pasos si no existe la RPC) */
    deleteWorkoutSession: builder.mutation<{ success: true }, { id_sesion: number }>({
      async queryFn({ id_sesion }) {
        // 1) usa RPC si existe (lo recomendado)
        const rpc = await supabase.rpc("delete_workout_session", { p_id_sesion: id_sesion });
        if (!rpc.error) return { data: { success: true } };

        // 2) fallback cliente (si no existe la función): borra sets y luego sesión
        // Nota: requerirá RLS que permita borrar por owner_uid
        const { error: sErr } = await supabase.from("EntrenamientoSets").delete().eq("id_sesion", id_sesion);
        if (sErr) return { error: sErr };
        const { error: eErr } = await supabase.from("Entrenamientos").delete().eq("id_sesion", id_sesion);
        if (eErr) return { error: eErr };

        return { data: { success: true } };
      },
      invalidatesTags: [{ type: "Workouts", id: "LIST" }],
      async onQueryStarted({ id_sesion }, { dispatch, queryFulfilled }) {
        // Optimista: quitar de la cache de la lista
        const patch = dispatch(
          workoutsApi.util.updateQueryData("listUserWorkouts", undefined, (draft) => {
            const i = draft.findIndex((w) => w.id_sesion === id_sesion);
            if (i >= 0) draft.splice(i, 1);
          })
        );
        try {
          await queryFulfilled;
        } catch {
          patch.undo();
        }
      },
    }),
  }),
});

export const { useCreateWorkoutSessionMutation, useListUserWorkoutsQuery, useDeleteWorkoutSessionMutation } =
  workoutsApi;
