import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { supabase } from "@/lib/supabase/client";
import { ExerciseQueryParams, ExerciseListResponse } from "@/types/exercises";

export const exercisesApi = createApi({
  reducerPath: "exercisesApi",
  baseQuery: fetchBaseQuery({ baseUrl: "/" }),
  tagTypes: ["Exercises"],
  endpoints: (builder) => ({
    getExercises: builder.query<ExerciseListResponse, ExerciseQueryParams>({
      queryFn: async ({ grupo_muscular, dificultad, search, from = 0, to = 19 }) => {
        let query = supabase.from("Ejercicios").select("*", { count: "exact" });

        if (grupo_muscular?.length) {
          query = query.in("grupo_muscular", grupo_muscular);
        }

        if (dificultad) {
          query = query.eq("dificultad", dificultad);
        }

        if (search) {
          query = query.ilike("nombre", `%${search}%`);
        }

        const { data, error, count } = await query.range(from, to).order("nombre");

        return { data, error, count };
      },
      providesTags: ["Exercises"],
    }),

    getMuscleGroups: builder.query<{ data: string[]; error: unknown }, void>({
      queryFn: async () => {
        const { data, error } = await supabase
          .from("Ejercicios")
          .select("grupo_muscular")
          .not("grupo_muscular", "is", null);

        if (error) return { error };

        const uniqueGroups = [...new Set(data.map((item) => item.grupo_muscular))];
        return { data: uniqueGroups };
      },
    }),
  }),
});

export const { useGetExercisesQuery, useGetMuscleGroupsQuery } = exercisesApi;
