import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ExerciseFilters } from "../components/ExerciseFilters";
import { ExerciseCard } from "../components/ExerciseCard";
import { SkeletonList } from "../components/SkeletonList";
import { useGetExercisesQuery } from "../exercisesSlice";
import { ExerciseFilters as ExerciseFiltersType, Exercise } from "@/types/exercises";
import { Loader2, Plus } from "lucide-react";

export default function ExerciseListPage() {
  const [filters, setFilters] = useState<ExerciseFiltersType>({});
  const [currentPage, setCurrentPage] = useState(0);
  const [allExercises, setAllExercises] = useState<Exercise[]>([]);
  const itemsPerPage = 20;

  const { data, isLoading, isFetching, error } = useGetExercisesQuery({
    ...filters,
    from: currentPage * itemsPerPage,
    to: (currentPage + 1) * itemsPerPage - 1,
  });

  const handleFiltersChange = useCallback((newFilters: ExerciseFiltersType) => {
    setFilters(newFilters);
    setCurrentPage(0); // Reset to first page when filters change
    setAllExercises([]); // Reset exercises when filters change
  }, []);

  const handleLoadMore = () => {
    setCurrentPage((prev) => prev + 1);
  };

  // Update allExercises when new data arrives
  useEffect(() => {
    if (data?.data) {
      if (currentPage === 0) {
        setAllExercises(data.data);
      } else {
        setAllExercises((prev) => [...prev, ...data.data]);
      }
    }
  }, [data?.data, currentPage]);

  const exercises = allExercises;
  const hasMore = data?.data?.length === itemsPerPage;
  const isInitialLoading = isLoading && currentPage === 0;

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
        <div className="text-center space-y-2">
          <h2 className="text-xl font-semibold text-destructive">Error al cargar ejercicios</h2>
          <p className="text-muted-foreground">No se pudieron cargar los ejercicios. Intenta de nuevo más tarde.</p>
        </div>
        <Button onClick={() => window.location.reload()}>Reintentar</Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Ejercicios</h1>
          <p className="text-muted-foreground">Explora nuestra biblioteca completa de ejercicios</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Nuevo Ejercicio
        </Button>
      </div>

      {/* Filters */}
      <ExerciseFilters onFiltersChange={handleFiltersChange} />

      {/* Results */}
      <div className="space-y-4">
        {isInitialLoading ? (
          <SkeletonList />
        ) : exercises.length > 0 ? (
          <>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {exercises.map((exercise) => (
                <ExerciseCard key={exercise.id} exercise={exercise} />
              ))}
            </div>

            {/* Load More Button */}
            {hasMore && (
              <div className="flex justify-center pt-6">
                <Button onClick={handleLoadMore} disabled={isFetching} variant="outline" className="min-w-[200px]">
                  {isFetching ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Cargando...
                    </>
                  ) : (
                    "Cargar más"
                  )}
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center min-h-[300px] space-y-4">
            <div className="text-center space-y-2">
              <h3 className="text-lg font-semibold">No se encontraron ejercicios</h3>
              <p className="text-muted-foreground">
                {filters.search || filters.grupo_muscular || filters.dificultad
                  ? "Intenta ajustar los filtros para encontrar más ejercicios."
                  : "No hay ejercicios disponibles en este momento."}
              </p>
            </div>
            {(filters.search || filters.grupo_muscular || filters.dificultad) && (
              <Button variant="outline" onClick={() => handleFiltersChange({})}>
                Limpiar filtros
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
