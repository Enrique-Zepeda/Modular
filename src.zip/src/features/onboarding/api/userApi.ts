import { supabase } from "@/lib/supabase/client";
import type { UserProfile } from "@/types/user";

export async function getSessionAuthUid(): Promise<string | null> {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session?.user?.id ?? null;
}

export async function getCurrentUserProfile(): Promise<UserProfile | null> {
  const authUid = await getSessionAuthUid();
  if (!authUid) return null;

  const { data, error } = await supabase
    .from<UserProfile>("Usuarios")
    .select("*")
    .eq("auth_uid", authUid)
    .maybeSingle();

  if (error) throw error;
  return data ?? null;
}

export async function checkUsernameAvailability(username: string): Promise<boolean> {
  if (!username) return false;

  // Intentar RPC (si existe)
  const { data, error } = await supabase.rpc("username_is_available", {
    p_username: username,
  });

  if (!error && typeof data === "boolean") return data;

  // Fallback: SELECT directo (case-insensitive)
  const { data: rows, error: selErr } = await supabase
    .from("Usuarios")
    .select("id_usuario")
    .ilike("username", username);

  if (selErr) throw selErr;
  return (rows?.length ?? 0) === 0;
}

export async function upsertCurrentUserProfile(payload: Partial<UserProfile>): Promise<UserProfile> {
  const { data: sess } = await supabase.auth.getSession();
  const authUid = sess?.session?.user?.id ?? null;
  const email = (sess?.session?.user?.email as string | null) ?? null;
  if (!authUid) throw new Error("No hay sesión activa");

  const base = {
    auth_uid: authUid,
    correo: email, // <- cubre NOT NULL/UNIQUE de correo en inserciones nuevas
    ...payload,
  };

  // 1) Intento con UPSERT (requiere índice único en auth_uid)
  const upsert = await supabase
    .from<UserProfile>("Usuarios")
    .upsert(base, { onConflict: "auth_uid" })
    .select("*")
    .single();

  if (!upsert.error) {
    return upsert.data as UserProfile;
  }

  // 2) Fallback: si falla el onConflict (400), hacemos select→update/insert
  //    Esto permite funcionar incluso si aún no aplicaste el índice único.
  const { data: existing, error: selErr } = await supabase
    .from<UserProfile>("Usuarios")
    .select("*")
    .eq("auth_uid", authUid)
    .maybeSingle();

  if (selErr) throw selErr;

  if (existing) {
    const { data: upd, error: updErr } = await supabase
      .from<UserProfile>("Usuarios")
      .update(base)
      .eq("id_usuario", existing.id_usuario)
      .select("*")
      .single();
    if (updErr) throw updErr;
    return upd as UserProfile;
  } else {
    const { data: ins, error: insErr } = await supabase.from<UserProfile>("Usuarios").insert(base).select("*").single();
    if (insErr) throw insErr;
    return ins as UserProfile;
  }
}
