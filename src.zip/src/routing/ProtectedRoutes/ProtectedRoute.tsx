import { useEffect, useState, type ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { supabase } from "@/lib/supabase/client";
import { useProfileCompletion } from "@/features/onboarding/hooks/useProfileCompletion";
import { SplinePointer } from "lucide-react";

type Props = {
  children: ReactNode;
  allowIncomplete?: boolean; // si true, deja pasar aunque el perfil no esté completo (para /onboarding)
};

export default function ProtectedRoute({ children, allowIncomplete = false }: Props) {
  const [authLoading, setAuthLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);

  const { loading: profileLoading, complete } = useProfileCompletion();

  // 👉 bypass de una sola vez tras completar el onboarding
  const [onboardingBypass, setOnboardingBypass] = useState(false);
  useEffect(() => {
    if (sessionStorage.getItem("onboardingJustCompleted") === "1") {
      setOnboardingBypass(true);
      sessionStorage.removeItem("onboardingJustCompleted");
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setIsAuthenticated(!!data.session);
      setAuthLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!mounted) return;
      setIsAuthenticated(!!session);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  if (authLoading) return <SplinePointer />; // solo espera la sesión
  if (!isAuthenticated) return <Navigate to="/login" replace />;

  if (!allowIncomplete) {
    // ✅ si venimos de completar el onboarding, dejamos pasar aunque el hook siga cargando
    if (onboardingBypass) return <>{children}</>;

    if (profileLoading) return <SplinePointer />;
    if (!complete) return <Navigate to="/onboarding" replace />;
  }

  return <>{children}</>;
}
