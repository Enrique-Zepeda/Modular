export interface UserProfile {
  id_usuario: number;
  auth_uid: string;
  correo: string | null;
  nombre: string | null;
  edad: number | null;
  peso: number | null;
  altura: number | null;
  nivel_experiencia: string | null;
  objetivo: string | null;
  username: string | null;
  // Campos extra que pudiera tener tu tabla quedarán ignorados
}

export const isProfileComplete = (p: Partial<UserProfile> | null | undefined) => {
  if (!p) return false;
  const required = [p.username, p.nombre, p.edad, p.peso, p.altura, p.nivel_experiencia, p.objetivo];
  return required.every((v) => v !== null && v !== undefined && String(v).trim() !== "");
};
