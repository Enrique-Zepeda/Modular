export interface Exercise {
  id: number;
  nombre: string;
  grupo_muscular: string;
  descripcion: string | null;
  equipamento: string | null;
  dificultad: "principiante" | "intermedio" | "avanzado";
  musculos_involucrados: string | null;
  ejemplo: string | null;
}

export interface ExerciseFilters {
  grupo_muscular?: string[];
  dificultad?: "principiante" | "intermedio" | "avanzado";
  search?: string;
}

export interface ExerciseListResponse {
  data: Exercise[];
  error: unknown;
  count?: number;
}

export interface ExerciseQueryParams {
  grupo_muscular?: string[];
  dificultad?: "principiante" | "intermedio" | "avanzado";
  search?: string;
  from?: number;
  to?: number;
}
