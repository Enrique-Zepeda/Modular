import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { ZodType } from "zod";

export function useAuthForm<T>(schema: ZodType<T>) {
  return useForm<T>({
    resolver: zodResolver(schema),
  });
}
